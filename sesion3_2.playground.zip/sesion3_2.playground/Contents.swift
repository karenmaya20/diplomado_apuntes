import UIKit

//: #Closures funciones anonimas
//: programacion funcional
//let nombreVar = {(param: tipoVariable) -> tipoVariable in //codigo }
let miClosure = { (number: Int) -> Int in
    let resultado = number * number
    return resultado
}

var listaNumeros = [2, 3, 4, 5, 6, 7]
var numerosMapeados = listaNumeros.map(miClosure)

numerosMapeados = listaNumeros.map({(number: Int) -> Int in
    let resultado = number * number
    return resultado
})
//ultima operacion hace el return
numerosMapeados = listaNumeros.map({ number in number * number })
numerosMapeados = listaNumeros.map{ number in number * number }
numerosMapeados = listaNumeros.map{ $0 * $0 }
print(numerosMapeados)
