import UIKit
//firma de la funcion manera de como esta declarada
//funcion regresa tuplas vacias, inmutable
var str = "Hello, playground"
func suma(){
    print("Sumando")
}
//let res = suma ()
suma()
//firma de la funcion anterior

func multiplica(x: Int, y: Int){
    print(x * y)
}

//la firma de la funcion es (Int, Int)
multiplica(x: 3, y:9)

func divide(_ x: Int, entre y: Int){ //_x esconde parametro de la funcion
    print(x / y)
}
divide(8, entre: 2)

func resta(_ x: Int, menos y: Int) -> Int{ //-> regresa tipoValor
    return x - y
}

let resultado = resta(10, menos: 2)
print(resultado)


var contador = 0
print(contador)
func incrementa(valor: inout Int){ //mandas referencia en lugar del valor
    valor += 9
    print(valor)
    
}
incrementa(valor: &contador)
print(contador)

//: Overloading
//Sobrecarga de funciones
func say(_ palabra: String){
    print(palabra)
}

func say(_ palabra: Int){
    print(palabra)
}

say(3)
say("Hola")

//CMD + SHITF + 7
//func niega() -> String{
//    return "no"
//}
//
//func niega() -> Int{
//    return 0
//}
//
//let valorNegado = niega()

//:Parametros por default
func creaTarjeta(nombre: String, saldo: Double = 0.0){
    print("Creando tarjeta para: \(nombre) con saldo de: \(saldo)")
}

creaTarjeta(nombre: "German", saldo:1.0)
creaTarjeta(nombre: "German")


//: Funciones con parametros variaticos (muchos valores)
func imprimeCadenas(_ cadenas: String ...){
    for cadena in cadenas{
        print(cadena)
    }
}
imprimeCadenas("hola","que tal","adios", "como estas?")

//:funciones como parametros
func ejecuta(a: Int, b: Int, funcion:(Int, Int)->Int) -> Int{
    let resultado = funcion(a, b)
    return resultado
}
//clousher
let resultadoFinal = ejecuta(a: 8, b: 4, funcion: resta)
print(resultadoFinal)
