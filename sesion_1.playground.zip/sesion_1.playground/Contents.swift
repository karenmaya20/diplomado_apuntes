import UIKit

var str = "Hello, playground"
var color = "rojo"

struct Animal{
    var nonbre:String
}

class Coche{
    var marca : String
    init (marca: String){
        
    }
}
