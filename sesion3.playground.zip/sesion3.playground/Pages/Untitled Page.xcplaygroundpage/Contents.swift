import UIKit
//-----------------------------Formas de usar nulos(optional) validadores
//:Opcionals: Puede recibir valor nulo
//Nulo: ausencia de .. (valor en memoria)
var nombre: String? //puede recibir un nulo
nombre = "Juan"
//print(nombre!) //desenvolvimiento forzado si y solo si hay un valor en esa variable

//Optional Binding: Se va a crear si y solo si no hay un null
//solo se ejecuta en el if; es decir es una var temporal
//let menos ciclos de reloj
nombre = "Jerry's"
if let nombreBackup = nombre {
    print("El nombre es: \(nombreBackup)")
}else{
    print("No hay nombre")
}
//: Nil coalescente
let nombreRespaldo = nombre ?? "Don nadie" //valor por default

//: Guard binding (Anti if)
func saluda(cadena: String?){
    guard let temp = cadena else{
        print("No hay valor")
        return
    }
    print(temp)
}

saluda(cadena: "Holi")
saluda(cadena: nil)

