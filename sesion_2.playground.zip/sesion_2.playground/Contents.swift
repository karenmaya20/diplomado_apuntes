import UIKit

var str = "Hello, playground"

class Alumno{
    var nombre: String
    init(nombre:String){
        self.nombre = nombre
    }
}
//
//let fer = Alumno(nombre: "Fer")
//print (fer)
//debugPrint(fer)
//print(fer.nombre)

//let juan = fer
//print(juan.nombre)
//juan.nombre = "Juan"
//print(juan.nombre)
//print(fer.nombre)
//debugPrint(juan)
let juan = Alumno (nombre: "Juan")

struct Profesor{
    var nombre: String
}

var mary = Profesor(nombre: "Mary") //instancia de una estructura llamado Profesor
var julio = mary //copia del contenido

print (julio.nombre)
julio.nombre = "Julio"
print(julio.nombre)
print(mary.nombre)

class Mascota{
    var nombre: String
    init (nombre : String){  //inicizalizar metodo constructor
        self.nombre = nombre
    }
    func actividad(tipo: String){ //metodo
        print("\(nombre) realiza \(tipo)")
        //print("\(self.nombre) 1realiza \(tipo)")

    }
}

let michi = Mascota(nombre: "michi")
michi.actividad(tipo: "el buen dormir")

struct Owner{
    var name : String
    var age: Int
    
    mutating func actividad(){
        self.age = self.age + 1
        //self.age = self.age + 1 buena practica pero no es necesario ? solo la variable es comun
        print("\(name) tiene \(age) anios")
    }
}

var luis = Owner(name: "Luis", age: 20)
luis.actividad()

