import UIKit

//--------------------PROTOCOLOS: actuan como un tipo de dato
//funcion sin implementacion es enumerar -> Protocolos
/* FIRMAS
 func reprobarAlumno(-a nombre:string, _ con promedio: Double) --------------(String, Double)
 func ejecutaAlumno(dato1: Stirng, dato2: String, funcion(String, Doble))----(String, String, (String, Doble))
 Protolo se convierte en un tipo de dato quien cumpla con la firma pasara
 struct/class/enum Nombre: protocolo{}
 Herencia multiple
 */
protocol Volador{
    func volar()
}

struct Ave: Volador{
    func volar(){
        print("Volar")
    }
}

class Humano: Volador{
    func volar(){
        print("humano volador")
    }
}

struct Perro{
    
}
func hazloVolar(_ filtro: Volador){
    filtro.volar()
}

let cotorro = Ave()
let cesar = Humano()
let firulais = Perro()

hazloVolar(cotorro)
hazloVolar(cesar)
//hazloVolar(firulais)




